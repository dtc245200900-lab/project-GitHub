# AI Prompt Log – FlashMart JOIN

## Prompt 1

Trong MySQL, JOIN khi không ghi rõ LEFT JOIN hay RIGHT JOIN sẽ hoạt động như thế nào?

### Nội dung tìm hiểu

JOIN mặc định là INNER JOIN. Nó chỉ trả về những bản ghi có giá trị khớp ở cả hai bảng. Vì vậy, các khách hàng chưa có đơn hàng hoặc sản phẩm chưa từng được bán sẽ không xuất hiện.

## Prompt 2

Khi sử dụng LEFT JOIN và COUNT để đếm số đơn hàng, nên sử dụng COUNT(*) hay COUNT(cột khóa chính của bảng Orders?

### Nội dung tìm hiểu

Nên sử dụng `COUNT(o.order_id)`. Khi không có đơn hàng, `o.order_id` là NULL nên COUNT trả về 0. `COUNT(*)` vẫn đếm dòng được tạo bởi LEFT JOIN nên có thể trả về 1.

## Prompt 3

Tại sao tìm sản phẩm chưa từng bán cần LEFT JOIN kết hợp WHERE o.order_id IS NULL?

### Nội dung tìm hiểu

LEFT JOIN giữ lại toàn bộ sản phẩm từ bảng Products. Những sản phẩm không có đơn hàng sẽ có các cột của Orders bằng NULL. Điều kiện `WHERE o.order_id IS NULL` dùng để lọc chính xác những sản phẩm chưa từng được bán.

## Prompt 4

Nếu sử dụng INNER JOIN thay cho LEFT JOIN trong bài toán sản phẩm chưa bán thì sao?

### Nội dung tìm hiểu

INNER JOIN loại bỏ ngay những sản phẩm không có bản ghi tương ứng trong Orders. Vì vậy sẽ không còn dòng có `o.order_id IS NULL`, khiến truy vấn không trả về Keyboard.
