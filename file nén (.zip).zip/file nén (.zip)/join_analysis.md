# Phân tích COUNT() trong LEFT JOIN

Trong bài toán Marketing, sử dụng LEFT JOIN giúp giữ lại toàn bộ khách hàng, kể cả những người chưa từng đặt hàng. Khi khách hàng chưa có đơn hàng, các cột của bảng Orders sẽ có giá trị NULL.

Vì vậy, sử dụng `COUNT(o.order_id)` sẽ chỉ đếm những dòng có `order_id` khác NULL. Với khách hàng chưa mua hàng, kết quả sẽ là 0.

Nếu sử dụng `COUNT(*)`, dòng kết quả được tạo ra bởi LEFT JOIN vẫn được tính, kể cả khi các cột của Orders đều NULL. Do đó khách hàng chưa mua hàng có thể bị đếm thành 1, dẫn đến sai kết quả.

Vì vậy, `COUNT(o.order_id)` là lựa chọn phù hợp để đếm số đơn hàng của từng khách hàng.
